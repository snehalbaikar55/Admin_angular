export class Editdeveloper{
    Developer: any ; 
   
}
