export class Adddeveloper{
    Developer : any;
   
}
